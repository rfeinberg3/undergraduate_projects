# KnowYourFood
KnowYourFood is a recipe app in which the user see recipes from different sites.

### User Stories

#### REQUIRED STORIES
- [x] User can see different recipes on the main page
- [x] User can see the recipes in the different categories such as Vegan, Vegetarian, Keto
- [x] User can favorite recipes and view them later
- [x] User can see the recipe on the particular website


### App Walkthrough GIF
<img src="http://g.recordit.co/RT1JP8o89N.gif" width=250><br>

### Notes
Made by Diya Jain, Suraj Kumar, Ryan Feinberg, Khoa Doan for the CodePath iOS Group Project.
