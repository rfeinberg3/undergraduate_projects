#include<string>
#include<iostream>
#include<fstream>
#include<vector>

const int ROW = 25, COLUMN = 25;
class Graph; // prototype of class Graph

//**********************************************************************************************************************
// Vertex object
class VertexObject{ 
public:
  std::string element;
  int index;
  Graph* g;
 
  VertexObject operator*(const VertexObject& v) {return v;}
  int incidentEdges();// prints all the incident edges of the vertex along with the opposite vertex for each incident edge
  bool isAdjacentTo(VertexObject* v);// returns 1 if the argument vertex is adjacent to this vertex

  VertexObject() {element = ""; // constructor
		  index = -1;}
};

//**********************************************************************************************************************
// Edge object
class EdgeObject{
public:
 std::string element;
 VertexObject* v1;
 VertexObject* v2;
 
 EdgeObject() {element = "";  // constructor
	       v1 = NULL;
	       v2 = NULL;}
 
 EdgeObject operator*(const EdgeObject& e) {return e;}
 void endVertices();  // prints the end vertices of the edge
 std::string opposite(VertexObject* v); // returns name of the vertex opposite the given one on this edge
 bool isAdjacentTo(EdgeObject* e); // returns 1 if the argument edge is adjacent to this one 
 bool isIncidentOn(VertexObject* v); // returns 1 if the argument vertex is incident on this edge
 bool empty() {if(element=="") return 1; // returns 1 if the edge is null
	       else return 0;}

};

//**********************************************************************************************************************
// Graph object
class Graph{
 private:
  std::vector<VertexObject*> V;// collection of vertex elements
  std::vector<EdgeObject*> E;// collection of pairs of vertex elements attatched to edge elements
  typedef std::vector<VertexObject*>::iterator V_Iterator;
  typedef std::vector<EdgeObject*>::iterator E_Iterator;
  int n;// size of the graph in terms of edges
  EdgeObject* Matrix[ROW][COLUMN];// matrix that points to edges incident on a vertex with index in Matrix
 public:
  Graph() {V.reserve(25);  //  constructor
           E.reserve(25);
           n = 0;
	   for(int i=0; i<ROW;i++) for(int j=0; j<COLUMN; j++) Matrix[i][j] = NULL;
           readFile();}

  int size() {return n;}
  void readFile();// read data into V and E from file
  void vertices();
  void edges();
  void insertVertex(std::string label);
  void insertEdge(VertexObject* v, VertexObject* w, std::string element);
  void eraseVertex(VertexObject* v);
  void eraseEdge(EdgeObject* e);
  VertexObject* getVertex(std::string label); // returns a pointer to a VertexObject with label equal to the given argument
  EdgeObject* getEdge(int num); // returns a pointer to an EdgeObject given its index in the vector
  
 friend class VertexObject;
};
//**********************************************************************************************************************

// incidentEdges function
int VertexObject::incidentEdges() {
   int count = 0; 
   for(int i = 0; i < g->size(); i++) 
     if(g->Matrix[i][index] != NULL) {
      std::cout << element + " to " << g->Matrix[i][index]->opposite(this) + " is " << g->Matrix[i][index]->element << std::endl;
      count++;
     }
   return count;
}

// isAdjacentTo function
bool VertexObject::isAdjacentTo(VertexObject* v) {
  for(int i = 0; i < g->size(); i++) {
     EdgeObject* E = g->Matrix[i][index];
     if((E != NULL) && (((v->element == E->v1->element) && (element == E->v2->element)) || ((v->element == E->v2->element) && (element == E->v1->element)))) 
       return 1; 
  }
  return 0;
}
//**********************************************************************************************************************


// endVertices function
void EdgeObject::endVertices() { // prints the names of the end vertices of the edge
  std::cout << v1->element << std::endl;
  std::cout << v2->element << std::endl; 
}

// opposite function
std::string EdgeObject::opposite(VertexObject* v) { // returns the name of the vertex opposite of the argument as a string type 
  if(v->element == v1->element) return v2->element;
  else if(v->element == v2->element) return v1->element;
  else return "The given vertex does not sit on this edge";
}

// isAdjacentTo function
bool EdgeObject::isAdjacentTo(EdgeObject* e) {  
  int current_row; int current_col;
  int question_row; int question_col;
  current_row = v1->index;
  current_col = v2->index;
  question_row = e->v1->index;
  question_col = e->v2->index;
  
  if((current_row == question_row) || (current_col == question_col)) return 1;
  else return 0; 
  
}

// isIncidentOn function
bool EdgeObject::isIncidentOn(VertexObject* v) {
  if((v->element == v1->element) || (v->element == v2->element)) return 1;
  else return 0;
}
//**********************************************************************************************************************


// vertices() function
void Graph::vertices() {
 for(V_Iterator V_it = V.begin(); V_it != V.end(); V_it++) {
  std::cout << (**V_it).element << std::endl;
 }
}

// edges() function
void Graph::edges() {
  for(E_Iterator E_it = E.begin(); E_it != E.end(); E_it++)
    std::cout << (**E_it).element << std::endl;
}

// insertVertex function 
void Graph::insertVertex(std::string label) { // assumes the vertex already has an elment value, but possibly not an index value
 V_Iterator V_it;
 for(V_it = V.begin(); V_it != V.end(); V_it++) 
   if((**V_it).element == label) break;
 if(V_it != V.end())  std::cout << "vertex already exists" << std::endl;
  
 else {
   V_it--;
   VertexObject* v = new VertexObject;
   v->element = label;
   v->index = ((**V_it).index) + 1; // sets index to 1 more than last vertex in the vector 
   v->g = this;
   V.push_back(v);
 }
}

// eraseVertex function
void Graph::eraseVertex(VertexObject* v) {
 V_Iterator V_it;
 E_Iterator E_it;
 int edgeNum = v->incidentEdges();// number of edges incident on v
 for(V_it = V.begin(); V_it != V.end(); V_it++) if((**V_it).element == v->element) break;
 if(V_it == V.end()) std::cout << "that vertex does not exist" << std::endl;
 else {
   V.erase(V_it);// erase vertex
   for(int i = 0; i < edgeNum; i++){
   for(E_it = E.begin(); E_it != E.end(); E_it++) if(((**E_it).v1 == v) || ((**E_it).v2) == v) break;
   eraseEdge(*E_it);// call to eraseEdge function to erase incident edges
   } 
   std::cout << "Erased vertex successfully" << std::endl;
 }
}


// insertEdge(v,w,x) function
void Graph::insertEdge(VertexObject* v, VertexObject* w, std::string element) {
 V_Iterator V_it;
 E_Iterator E_it;
 for(V_it = V.begin(); V_it != V.end(); V_it++) if(((*V_it) == v) || (*V_it) == w) break;
 for(E_it = E.begin(); E_it != E.end(); E_it++) if((**E_it).element == element) break;
  if(V_it == V.end()) {
    std::cout << "Vertices do not exist" << std::endl;
    return;
  }
  if(E_it != E.end()) {
   std::cout << "Edge already exists" << std::endl;
   return;
  }
  EdgeObject* e = new EdgeObject;
  e->v1 = v;
  e->v2 = w;
  e->element = element;
  Matrix[v->index][w->index] = e;
  Matrix[w->index][v->index] = e;
  E.push_back(e);
  std::cout << "Edge added successfully" << std::endl;  
}

// eraseEdge function
void Graph::eraseEdge(EdgeObject* e) {
  E_Iterator E_it;
  for(E_it = E.begin(); E_it != E.end(); E_it++) if((**E_it).element == e->element) break;
  if(E_it == E.end()) std::cout << "that edge does not exist" << std::endl;
  else {
   Matrix[e->v1->index][e->v2->index] = NULL;
   Matrix[e->v2->index][e->v1->index] = NULL;
   E.erase(E_it);
   std::cout << "Erased edge successfully" << std::endl;
 }
}

// getVertex function
VertexObject* Graph::getVertex(std::string label) {
  V_Iterator V_it = V.begin();  
  while((V_it != V.end()) && ((**V_it).element != label)) V_it++;
    if(V_it != V.end()) return *V_it;
    else {std::cout << "Vertex not found" << std::endl; return NULL;}
}

// getEdge function
EdgeObject* Graph::getEdge(int num) {
  E_Iterator E_it = E.begin() + num; 
  return *E_it;
}

// readFile function
void Graph::readFile(){

  std::ifstream iFile;
  std::string filename;
  std::string vertex1;
  std::string vertex2;
  std::string edgeLabel;
  std::string first_line;
  V_Iterator V_it;
  E_Iterator E_it;
  int i=0;
  int vertexCount=0;
  std::cout << "Enter file name: "; // get file to open
  std::cin >> filename;
  while (std::cin.fail()) { // input validation for filename
    std::cout << "Try again: ";
    std::cin.clear();
    std::cin.ignore(100, '\n');
    std::cin >> filename;
  }

  iFile.open(filename); // open a file to read

  while(!iFile.eof()) { // begin code fragment to calculate number of vertices
     getline(iFile, first_line, ',');  
     vertexCount++;
  }
  iFile.close(); // end code fragment

  iFile.open(filename); // reopen file

  if (iFile.is_open()) { // checking whether the file is open
    while(i < vertexCount) {
     if(i >= 1) getline(iFile, first_line, ' ');
     VertexObject* v = new VertexObject;
     if(i == 4) getline(iFile, first_line, '\n');
     else getline(iFile, first_line, ','); // gets first line
     for(int x = 0; first_line[x] != '\0'; x++) { // tests and fixes inputs that would break the program
       if((isspace(first_line[x])) && (first_line[x+1] == '\0')) {
         first_line[x] = first_line[x+1];
         first_line.pop_back();
	 break;
       }
       if((isspace(first_line[x])) && isspace(first_line[x+1])) {
         first_line = first_line.substr(0, x);
         first_line += '\0';
       }
     }
     v->element = first_line;
     v->index = i;
     v->g = this;
     V.push_back(v); // store vertex in vector
     i++;
    } // end while 1
    while(!iFile.eof()) {
     int row; int col;
     EdgeObject* e = new EdgeObject;
     getline(iFile, vertex1, '\t');
     getline(iFile, vertex2, '\t');
     getline(iFile, edgeLabel, '\n');
     if(isspace(vertex1[0])) break;
     n++;// increment the size of the graph (in terms of edges)
     for(V_it = V.begin(); V_it != V.end(); V_it++){
      if((**V_it).element == vertex1) {
        e->element = edgeLabel;
        e->v1 = *V_it;
        row = (**V_it).index;
      }
     }//end for1
     for(V_it = V.begin(); V_it != V.end(); V_it++){
      if((**V_it).element == vertex2){
           e->v2 = *V_it;
           col = (**V_it).index;
      } 
     }//end for2
     Matrix[row][col] = e; // spot in matrix to point to edge
     Matrix[col][row] = e; // spot in matrix to point to edge
     E.push_back(e); // store edge in vector
    } // end while 2
  }// end if 
  else {
    std::cout << "Could not open file." << std::endl;
    return;
  }
  iFile.close();
  
  std::cout << "Thank you, your graph is ready\n" << std::endl;
}//end function
//**********************************************************************************************************************


int main() {
  int select;
  std::string name, label1, label2, label3;
  Graph G;
  while(select != 6) {
  std::cout << "--------------------------" << std::endl;
  std::cout << "What would you like to do?" << std::endl; 
  std::cout << "--------------------------\n" << std::endl;

  std::cout << "1. Find edges incident of a vertex" << std::endl;
  std::cout << "2. Find a path in the graph" << std::endl;
  std::cout << "3. Insert an edge" << std::endl;
  std::cout << "4. Erase a vertex" << std::endl;
  std::cout << "5. Print graphs vertices and edges" << std::endl;
  std::cout << "6. Exit program" << std::endl;

  std::cin >> select;
  while(select > 6 || select < 1 || std::cin.fail()) {
   std::cout << "invalid input, try again" << std::endl;
   std::cin.clear();
   std::cin.ignore();
   std::cin >> select;
  }
  switch(select) {
   case 1:
    std::cout << "***********************************" << std::endl;
    std::cout << "What is the vertex label? ";
    std::cin.ignore();
    std::getline(std::cin, name);
    std::cout << "***********************************" << std::endl;
    if(G.getVertex(name) == NULL) break; //check if vertex exists
    G.getVertex(name)->incidentEdges();
    std::cout << "***********************************" << std::endl;
    std::cout << '\n' << std::endl;
    break;

   case 2:
    std::cout << "What is the name of vertex 1? ";
    std::cin.ignore();
    std::getline(std::cin, label1);
    std::cout << "What is the name of vertex 2? ";
    std::getline(std::cin, label2);
    std::cout << "What is the name of vetex 3? ";
    std::getline(std::cin, label3);
    std::cout << "***********************************" << std::endl;
    if(G.getVertex(label1) == NULL || G.getVertex(label2) == NULL || G.getVertex(label3) == NULL) break; //check if vertices exist
    if(G.getVertex(label1)->isAdjacentTo(G.getVertex(label2)) && G.getVertex(label2)->isAdjacentTo(G.getVertex(label3))) std::cout << label1 + " to " + label2 + " to " + label3 << std::endl;
    else if(G.getVertex(label2)->isAdjacentTo(G.getVertex(label1)) && G.getVertex(label3)->isAdjacentTo(G.getVertex(label1))) std::cout << label2 + " to " + label1 + " to " + label3 << std::endl;
    else if(G.getVertex(label2)->isAdjacentTo(G.getVertex(label1)) && G.getVertex(label3)->isAdjacentTo(G.getVertex(label2))) std::cout << label1 + " to " + label2 + " to " + label3 << std::endl;
    else if(G.getVertex(label1)->isAdjacentTo(G.getVertex(label3)) && G.getVertex(label2)->isAdjacentTo(G.getVertex(label3))) std::cout << label1 + " to " + label3 + " to " + label2 << std::endl;
    else std::cout << "There is no such path" << std::endl;
    std::cout << "***********************************" << std::endl;
    std::cout << '\n' << std::endl;
    break;

   case 3:
    std::cout << "What is the name of vertex 1? ";
    std::cin.ignore();
    std::getline(std::cin, label1);
    std::cout << "What is the name of vertex 2? ";
    std::getline(std::cin, label2);
    std::cout << "What is the name of the edge you would like to insert? ";
    std::getline(std::cin, name);
    std::cout << "***********************************" << std::endl;
    G.insertEdge(G.getVertex(label1), G.getVertex(label2), name);
    std::cout << "***********************************" << std::endl;
    std::cout << '\n' << std::endl;
    break;

   case 4:
    std::cout << "What is the name of the vertex you would like to erase? ";
    std::cin.ignore();
    std::getline(std::cin, name);
    if(G.getVertex(name) == NULL) break; //check if vertex exists
    std::cout << "***********************************" << std::endl;
    G.eraseVertex(G.getVertex(name));
    std::cout << "***********************************" << std::endl;
    break;
    
   case 5:
    std::cout << "***********************************" << std::endl;
    std::cout << "Your current graphs vertices are: " << std::endl;
    G.vertices();
    std::cout << "***********************************" << std::endl;
    std::cout << "Your current graphs edges are: " << std::endl;
    G.edges();
    break;

   case 6:
    std::cout << "***********************************" << std::endl;
    std::cout << "Goodbye!" << std::endl;
    std::cout << "***********************************" << std::endl;
    break;
  }// end switch
  }// end main while
return 0;
}
